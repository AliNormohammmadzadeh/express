module.exports = {
    MongoURI: "mongodb+srv://teb:akza1374@webproject.kp5yv.mongodb.net/project2?retryWrites=true&w=majority"
}